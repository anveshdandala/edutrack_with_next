
# TestSprite AI Testing Report(MCP)

---

## 1️⃣ Document Metadata
- **Project Name:** edutrack_with_next
- **Date:** 2026-01-03
- **Prepared by:** TestSprite AI Team

---

## 2️⃣ Requirement Validation Summary

#### Test TC001
- **Test Name:** Successful Login with Correct Credentials
- **Test Code:** [TC001_Successful_Login_with_Correct_Credentials.py](./TC001_Successful_Login_with_Correct_Credentials.py)
- **Test Error:** Login attempt with valid credentials on tenant-specific login page failed due to an internal server error. No redirection to the role-specific dashboard occurred, and login could not be verified. Recommend reporting this backend issue for resolution before retrying login tests.
Browser Console Logs:
[WARNING] %c%s%c [serverFetch] No access token found in cookies background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:2287:27)
[ERROR] %c%s%c [Fetch Error] Status: 404 | URL: http://127.0.0.1:8000/api/vmeg/auth/users/me/ background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] %c%s%c [Fetch Error] Body: background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   <!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <title>Page not found at /api/vmeg/auth/users/me/</title>
  <meta name="robots" content="NONE,NOARCHIVE">
  <style>
    html * { padding:0; margin:0; }
    body * { padding:10px 20px; }
    body * * { padding:0; }
    body { font-family: sans-serif; background:#eee; color:#000; }
    body > :where(header, main, footer) { border-bottom:1px solid #ddd; }
    h1 { font-weight:normal; margin-bottom:.4em; }
    h1 small { font-size:60%; color:#666; font-weight:normal; }
    table { border:none; border-collapse: collapse; width:100%; }
    td, th { vertical-align:top; padding:2px 3px; }
    th { width:12em; text-align:right; color:#666; padding-right:.5em; }
    #info { background:#f6f6f6; }
    #info ol { margin: 0.5em 4em; }
    #info ol li { font-family: monospace; }
    #summary { background: #ffc; }
    #explanation { background:#eee; border-bottom: 0px none; }
    pre.exception_value { font-family: sans-serif; color: #575757; font-size: 1.5em; margin: 10px 0 10px 0; }
  </style>
</head>
<body>
  <header id="summary">
    <h1>Page not found <small>(404)</small></h1>
    
    <table class="meta">
      <tr>
        <th scope="row">Request Method:</th>
        <td>GET</td>
      </tr>
      <tr>
        <th scope="row">Request URL:</th>
        <td>http://127.0.0.1:8000/api/vmeg/auth/users/me/</td>
      </tr>
      
    </table>
  </header>

  <main id="info">
    
      <p>
      Using the URLconf defined in <code>edutrack.urls_public_dynamically_tenant_prefixed</code>,
      Django tried these URL patterns, in this order:
      </p>
      <ol>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                admin/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                public/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                silk/
                
              </code>
            
          </li>
        
      </ol>
      <p>
        
          The current path, <code>api/vmeg/auth/users/me/</code>,
        
        didn’t match any of these.
      </p>
    
  </main>

  <footer id="explanation">
    <p>
      You’re seeing this error because you have <code>DEBUG = True</code> in
      your Django settings file. Change that to <code>False</code>, and Django
      will display a standard 404 page.
    </p>
  </footer>
</body>
</html>
 (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] Failed to load resource: the server responded with a status of 500 (Internal Server Error) (at http://localhost:3000/api/auth/login:0:0)
[ERROR] Login Flow Error: Error: Internal Server Error
    at login (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:24:15)
    at async handleSubmit (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:554:13) (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
- **Test Visualization and Result:** https://www.testsprite.com/dashboard/mcp/tests/97dcf2d5-c58c-4828-b84b-e0379bda862d/f884c615-2db2-45b0-af9b-cf98982300b5
- **Status:** ❌ Failed
- **Analysis / Findings:** {{TODO:AI_ANALYSIS}}.
---

#### Test TC002
- **Test Name:** Login Failure with Incorrect Credentials
- **Test Code:** [TC002_Login_Failure_with_Incorrect_Credentials.py](./TC002_Login_Failure_with_Incorrect_Credentials.py)
- **Test Error:** Login test with invalid credentials failed due to Internal Server Error. Proper error message for invalid login is not displayed. Stopping further testing and reporting the issue.
Browser Console Logs:
[WARNING] %c%s%c [serverFetch] No access token found in cookies background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:2287:27)
[ERROR] %c%s%c [Fetch Error] Status: 404 | URL: http://127.0.0.1:8000/api/vmeg/auth/users/me/ background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] %c%s%c [Fetch Error] Body: background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   <!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <title>Page not found at /api/vmeg/auth/users/me/</title>
  <meta name="robots" content="NONE,NOARCHIVE">
  <style>
    html * { padding:0; margin:0; }
    body * { padding:10px 20px; }
    body * * { padding:0; }
    body { font-family: sans-serif; background:#eee; color:#000; }
    body > :where(header, main, footer) { border-bottom:1px solid #ddd; }
    h1 { font-weight:normal; margin-bottom:.4em; }
    h1 small { font-size:60%; color:#666; font-weight:normal; }
    table { border:none; border-collapse: collapse; width:100%; }
    td, th { vertical-align:top; padding:2px 3px; }
    th { width:12em; text-align:right; color:#666; padding-right:.5em; }
    #info { background:#f6f6f6; }
    #info ol { margin: 0.5em 4em; }
    #info ol li { font-family: monospace; }
    #summary { background: #ffc; }
    #explanation { background:#eee; border-bottom: 0px none; }
    pre.exception_value { font-family: sans-serif; color: #575757; font-size: 1.5em; margin: 10px 0 10px 0; }
  </style>
</head>
<body>
  <header id="summary">
    <h1>Page not found <small>(404)</small></h1>
    
    <table class="meta">
      <tr>
        <th scope="row">Request Method:</th>
        <td>GET</td>
      </tr>
      <tr>
        <th scope="row">Request URL:</th>
        <td>http://127.0.0.1:8000/api/vmeg/auth/users/me/</td>
      </tr>
      
    </table>
  </header>

  <main id="info">
    
      <p>
      Using the URLconf defined in <code>edutrack.urls_public_dynamically_tenant_prefixed</code>,
      Django tried these URL patterns, in this order:
      </p>
      <ol>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                admin/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                public/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                silk/
                
              </code>
            
          </li>
        
      </ol>
      <p>
        
          The current path, <code>api/vmeg/auth/users/me/</code>,
        
        didn’t match any of these.
      </p>
    
  </main>

  <footer id="explanation">
    <p>
      You’re seeing this error because you have <code>DEBUG = True</code> in
      your Django settings file. Change that to <code>False</code>, and Django
      will display a standard 404 page.
    </p>
  </footer>
</body>
</html>
 (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] Failed to load resource: the server responded with a status of 500 (Internal Server Error) (at http://localhost:3000/api/auth/login:0:0)
[ERROR] Login Flow Error: Error: Internal Server Error
    at login (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:24:15)
    at async handleSubmit (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:554:13) (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
- **Test Visualization and Result:** https://www.testsprite.com/dashboard/mcp/tests/97dcf2d5-c58c-4828-b84b-e0379bda862d/aa1bc593-becf-404f-a7d1-a7493b1f3078
- **Status:** ❌ Failed
- **Analysis / Findings:** {{TODO:AI_ANALYSIS}}.
---

#### Test TC003
- **Test Name:** Token Expiry and Automatic Logout
- **Test Code:** [TC003_Token_Expiry_and_Automatic_Logout.py](./TC003_Token_Expiry_and_Automatic_Logout.py)
- **Test Error:** Testing stopped due to missing login page causing 404 error. Cannot proceed with login and token expiry test.
Browser Console Logs:
[ERROR] Failed to load resource: the server responded with a status of 404 (Not Found) (at http://localhost:3000/auth?_rsc=vusbg:0:0)
[ERROR] Failed to load resource: the server responded with a status of 404 (Not Found) (at http://localhost:3000/auth:0:0)
- **Test Visualization and Result:** https://www.testsprite.com/dashboard/mcp/tests/97dcf2d5-c58c-4828-b84b-e0379bda862d/8801f702-bd7a-48de-8815-a3561a49b1b7
- **Status:** ❌ Failed
- **Analysis / Findings:** {{TODO:AI_ANALYSIS}}.
---

#### Test TC004
- **Test Name:** Cross-Tenant Access Restriction
- **Test Code:** [TC004_Cross_Tenant_Access_Restriction.py](./TC004_Cross_Tenant_Access_Restriction.py)
- **Test Error:** Testing stopped due to Internal Server Error on login preventing further validation of tenant isolation. Issue reported for resolution.
Browser Console Logs:
[WARNING] %c%s%c [serverFetch] No access token found in cookies background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:2287:27)
[ERROR] %c%s%c [Fetch Error] Status: 404 | URL: http://127.0.0.1:8000/api/vmeg/auth/users/me/ background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] %c%s%c [Fetch Error] Body: background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   <!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <title>Page not found at /api/vmeg/auth/users/me/</title>
  <meta name="robots" content="NONE,NOARCHIVE">
  <style>
    html * { padding:0; margin:0; }
    body * { padding:10px 20px; }
    body * * { padding:0; }
    body { font-family: sans-serif; background:#eee; color:#000; }
    body > :where(header, main, footer) { border-bottom:1px solid #ddd; }
    h1 { font-weight:normal; margin-bottom:.4em; }
    h1 small { font-size:60%; color:#666; font-weight:normal; }
    table { border:none; border-collapse: collapse; width:100%; }
    td, th { vertical-align:top; padding:2px 3px; }
    th { width:12em; text-align:right; color:#666; padding-right:.5em; }
    #info { background:#f6f6f6; }
    #info ol { margin: 0.5em 4em; }
    #info ol li { font-family: monospace; }
    #summary { background: #ffc; }
    #explanation { background:#eee; border-bottom: 0px none; }
    pre.exception_value { font-family: sans-serif; color: #575757; font-size: 1.5em; margin: 10px 0 10px 0; }
  </style>
</head>
<body>
  <header id="summary">
    <h1>Page not found <small>(404)</small></h1>
    
    <table class="meta">
      <tr>
        <th scope="row">Request Method:</th>
        <td>GET</td>
      </tr>
      <tr>
        <th scope="row">Request URL:</th>
        <td>http://127.0.0.1:8000/api/vmeg/auth/users/me/</td>
      </tr>
      
    </table>
  </header>

  <main id="info">
    
      <p>
      Using the URLconf defined in <code>edutrack.urls_public_dynamically_tenant_prefixed</code>,
      Django tried these URL patterns, in this order:
      </p>
      <ol>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                admin/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                public/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                silk/
                
              </code>
            
          </li>
        
      </ol>
      <p>
        
          The current path, <code>api/vmeg/auth/users/me/</code>,
        
        didn’t match any of these.
      </p>
    
  </main>

  <footer id="explanation">
    <p>
      You’re seeing this error because you have <code>DEBUG = True</code> in
      your Django settings file. Change that to <code>False</code>, and Django
      will display a standard 404 page.
    </p>
  </footer>
</body>
</html>
 (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] Failed to load resource: the server responded with a status of 500 (Internal Server Error) (at http://localhost:3000/api/auth/login:0:0)
[ERROR] Login Flow Error: Error: Internal Server Error
    at login (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:24:15)
    at async handleSubmit (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:554:13) (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
- **Test Visualization and Result:** https://www.testsprite.com/dashboard/mcp/tests/97dcf2d5-c58c-4828-b84b-e0379bda862d/f1bcd38b-f705-4f41-a4d8-e9980ee3019e
- **Status:** ❌ Failed
- **Analysis / Findings:** {{TODO:AI_ANALYSIS}}.
---

#### Test TC005
- **Test Name:** Role-Based Access Control UI and Data Verification
- **Test Code:** [TC005_Role_Based_Access_Control_UI_and_Data_Verification.py](./TC005_Role_Based_Access_Control_UI_and_Data_Verification.py)
- **Test Error:** Login failed due to Internal Server Error on the student login page. Cannot proceed with verifying role-based UI components for student, faculty, and institution admin roles. Please resolve the server error and retry.
Browser Console Logs:
[WARNING] %c%s%c [serverFetch] No access token found in cookies background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:2287:27)
[ERROR] %c%s%c [Fetch Error] Status: 404 | URL: http://127.0.0.1:8000/api/vmeg/auth/users/me/ background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] %c%s%c [Fetch Error] Body: background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   <!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <title>Page not found at /api/vmeg/auth/users/me/</title>
  <meta name="robots" content="NONE,NOARCHIVE">
  <style>
    html * { padding:0; margin:0; }
    body * { padding:10px 20px; }
    body * * { padding:0; }
    body { font-family: sans-serif; background:#eee; color:#000; }
    body > :where(header, main, footer) { border-bottom:1px solid #ddd; }
    h1 { font-weight:normal; margin-bottom:.4em; }
    h1 small { font-size:60%; color:#666; font-weight:normal; }
    table { border:none; border-collapse: collapse; width:100%; }
    td, th { vertical-align:top; padding:2px 3px; }
    th { width:12em; text-align:right; color:#666; padding-right:.5em; }
    #info { background:#f6f6f6; }
    #info ol { margin: 0.5em 4em; }
    #info ol li { font-family: monospace; }
    #summary { background: #ffc; }
    #explanation { background:#eee; border-bottom: 0px none; }
    pre.exception_value { font-family: sans-serif; color: #575757; font-size: 1.5em; margin: 10px 0 10px 0; }
  </style>
</head>
<body>
  <header id="summary">
    <h1>Page not found <small>(404)</small></h1>
    
    <table class="meta">
      <tr>
        <th scope="row">Request Method:</th>
        <td>GET</td>
      </tr>
      <tr>
        <th scope="row">Request URL:</th>
        <td>http://127.0.0.1:8000/api/vmeg/auth/users/me/</td>
      </tr>
      
    </table>
  </header>

  <main id="info">
    
      <p>
      Using the URLconf defined in <code>edutrack.urls_public_dynamically_tenant_prefixed</code>,
      Django tried these URL patterns, in this order:
      </p>
      <ol>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                admin/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                public/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                silk/
                
              </code>
            
          </li>
        
      </ol>
      <p>
        
          The current path, <code>api/vmeg/auth/users/me/</code>,
        
        didn’t match any of these.
      </p>
    
  </main>

  <footer id="explanation">
    <p>
      You’re seeing this error because you have <code>DEBUG = True</code> in
      your Django settings file. Change that to <code>False</code>, and Django
      will display a standard 404 page.
    </p>
  </footer>
</body>
</html>
 (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] Failed to load resource: the server responded with a status of 500 (Internal Server Error) (at http://localhost:3000/api/auth/login:0:0)
[ERROR] Login Flow Error: Error: Internal Server Error
    at login (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:24:15)
    at async handleSubmit (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:554:13) (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] Failed to load resource: the server responded with a status of 500 (Internal Server Error) (at http://localhost:3000/api/auth/login:0:0)
[ERROR] Login Flow Error: Error: Internal Server Error
    at login (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:24:15)
    at async handleSubmit (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:554:13) (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
- **Test Visualization and Result:** https://www.testsprite.com/dashboard/mcp/tests/97dcf2d5-c58c-4828-b84b-e0379bda862d/66dbd7dc-f38f-46ae-b32c-9396364654b1
- **Status:** ❌ Failed
- **Analysis / Findings:** {{TODO:AI_ANALYSIS}}.
---

#### Test TC006
- **Test Name:** Certificate Upload Validation - File Type and Size
- **Test Code:** [TC006_Certificate_Upload_Validation___File_Type_and_Size.py](./TC006_Certificate_Upload_Validation___File_Type_and_Size.py)
- **Test Error:** Testing stopped due to Internal Server Error on login page preventing access to student dashboard and further certificate upload validation. Issue reported for resolution.
Browser Console Logs:
[WARNING] %c%s%c [serverFetch] No access token found in cookies background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:2287:27)
[ERROR] %c%s%c [Fetch Error] Status: 404 | URL: http://127.0.0.1:8000/api/vmeg/auth/users/me/ background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] %c%s%c [Fetch Error] Body: background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   <!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <title>Page not found at /api/vmeg/auth/users/me/</title>
  <meta name="robots" content="NONE,NOARCHIVE">
  <style>
    html * { padding:0; margin:0; }
    body * { padding:10px 20px; }
    body * * { padding:0; }
    body { font-family: sans-serif; background:#eee; color:#000; }
    body > :where(header, main, footer) { border-bottom:1px solid #ddd; }
    h1 { font-weight:normal; margin-bottom:.4em; }
    h1 small { font-size:60%; color:#666; font-weight:normal; }
    table { border:none; border-collapse: collapse; width:100%; }
    td, th { vertical-align:top; padding:2px 3px; }
    th { width:12em; text-align:right; color:#666; padding-right:.5em; }
    #info { background:#f6f6f6; }
    #info ol { margin: 0.5em 4em; }
    #info ol li { font-family: monospace; }
    #summary { background: #ffc; }
    #explanation { background:#eee; border-bottom: 0px none; }
    pre.exception_value { font-family: sans-serif; color: #575757; font-size: 1.5em; margin: 10px 0 10px 0; }
  </style>
</head>
<body>
  <header id="summary">
    <h1>Page not found <small>(404)</small></h1>
    
    <table class="meta">
      <tr>
        <th scope="row">Request Method:</th>
        <td>GET</td>
      </tr>
      <tr>
        <th scope="row">Request URL:</th>
        <td>http://127.0.0.1:8000/api/vmeg/auth/users/me/</td>
      </tr>
      
    </table>
  </header>

  <main id="info">
    
      <p>
      Using the URLconf defined in <code>edutrack.urls_public_dynamically_tenant_prefixed</code>,
      Django tried these URL patterns, in this order:
      </p>
      <ol>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                admin/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                public/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                silk/
                
              </code>
            
          </li>
        
      </ol>
      <p>
        
          The current path, <code>api/vmeg/auth/users/me/</code>,
        
        didn’t match any of these.
      </p>
    
  </main>

  <footer id="explanation">
    <p>
      You’re seeing this error because you have <code>DEBUG = True</code> in
      your Django settings file. Change that to <code>False</code>, and Django
      will display a standard 404 page.
    </p>
  </footer>
</body>
</html>
 (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] Failed to load resource: the server responded with a status of 500 (Internal Server Error) (at http://localhost:3000/api/auth/login:0:0)
[ERROR] Login Flow Error: Error: Internal Server Error
    at login (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:24:15)
    at async handleSubmit (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:554:13) (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
- **Test Visualization and Result:** https://www.testsprite.com/dashboard/mcp/tests/97dcf2d5-c58c-4828-b84b-e0379bda862d/0fd43388-1c3c-43ae-a3a3-5b4c287b0dcd
- **Status:** ❌ Failed
- **Analysis / Findings:** {{TODO:AI_ANALYSIS}}.
---

#### Test TC007
- **Test Name:** Faculty Certificate Approval and Bulk Actions
- **Test Code:** [TC007_Faculty_Certificate_Approval_and_Bulk_Actions.py](./TC007_Faculty_Certificate_Approval_and_Bulk_Actions.py)
- **Test Error:** Unable to complete the task because the faculty user login is blocked by an Internal Server Error on the login page. The error prevents access to the faculty dashboard where certificate approvals can be tested. Please resolve the server error to proceed with testing.
Browser Console Logs:
[WARNING] %c%s%c [serverFetch] No access token found in cookies background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:2287:27)
[ERROR] %c%s%c [Fetch Error] Status: 404 | URL: http://127.0.0.1:8000/api/vmeg/auth/users/me/ background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] %c%s%c [Fetch Error] Body: background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   <!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <title>Page not found at /api/vmeg/auth/users/me/</title>
  <meta name="robots" content="NONE,NOARCHIVE">
  <style>
    html * { padding:0; margin:0; }
    body * { padding:10px 20px; }
    body * * { padding:0; }
    body { font-family: sans-serif; background:#eee; color:#000; }
    body > :where(header, main, footer) { border-bottom:1px solid #ddd; }
    h1 { font-weight:normal; margin-bottom:.4em; }
    h1 small { font-size:60%; color:#666; font-weight:normal; }
    table { border:none; border-collapse: collapse; width:100%; }
    td, th { vertical-align:top; padding:2px 3px; }
    th { width:12em; text-align:right; color:#666; padding-right:.5em; }
    #info { background:#f6f6f6; }
    #info ol { margin: 0.5em 4em; }
    #info ol li { font-family: monospace; }
    #summary { background: #ffc; }
    #explanation { background:#eee; border-bottom: 0px none; }
    pre.exception_value { font-family: sans-serif; color: #575757; font-size: 1.5em; margin: 10px 0 10px 0; }
  </style>
</head>
<body>
  <header id="summary">
    <h1>Page not found <small>(404)</small></h1>
    
    <table class="meta">
      <tr>
        <th scope="row">Request Method:</th>
        <td>GET</td>
      </tr>
      <tr>
        <th scope="row">Request URL:</th>
        <td>http://127.0.0.1:8000/api/vmeg/auth/users/me/</td>
      </tr>
      
    </table>
  </header>

  <main id="info">
    
      <p>
      Using the URLconf defined in <code>edutrack.urls_public_dynamically_tenant_prefixed</code>,
      Django tried these URL patterns, in this order:
      </p>
      <ol>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                admin/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                public/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                silk/
                
              </code>
            
          </li>
        
      </ol>
      <p>
        
          The current path, <code>api/vmeg/auth/users/me/</code>,
        
        didn’t match any of these.
      </p>
    
  </main>

  <footer id="explanation">
    <p>
      You’re seeing this error because you have <code>DEBUG = True</code> in
      your Django settings file. Change that to <code>False</code>, and Django
      will display a standard 404 page.
    </p>
  </footer>
</body>
</html>
 (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] Failed to load resource: the server responded with a status of 500 (Internal Server Error) (at http://localhost:3000/api/auth/login:0:0)
[ERROR] Login Flow Error: Error: Internal Server Error
    at login (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:24:15)
    at async handleSubmit (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:554:13) (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
- **Test Visualization and Result:** https://www.testsprite.com/dashboard/mcp/tests/97dcf2d5-c58c-4828-b84b-e0379bda862d/1f4894b4-9e0b-4d55-a5e4-2d04a8b19dee
- **Status:** ❌ Failed
- **Analysis / Findings:** {{TODO:AI_ANALYSIS}}.
---

#### Test TC008
- **Test Name:** Logout Flow and Token Clearance
- **Test Code:** [TC008_Logout_Flow_and_Token_Clearance.py](./TC008_Logout_Flow_and_Token_Clearance.py)
- **Test Error:** Testing stopped due to broken login link causing 404 error page. Cannot proceed with logout validation.
Browser Console Logs:
[ERROR] Failed to load resource: the server responded with a status of 404 (Not Found) (at http://localhost:3000/auth?_rsc=vusbg:0:0)
[ERROR] Failed to load resource: the server responded with a status of 404 (Not Found) (at http://localhost:3000/auth:0:0)
- **Test Visualization and Result:** https://www.testsprite.com/dashboard/mcp/tests/97dcf2d5-c58c-4828-b84b-e0379bda862d/624b9265-9bd9-43a9-b210-3a2bfee4396c
- **Status:** ❌ Failed
- **Analysis / Findings:** {{TODO:AI_ANALYSIS}}.
---

#### Test TC009
- **Test Name:** Responsive UI Rendering on Desktop, Tablet, and Mobile
- **Test Code:** [TC009_Responsive_UI_Rendering_on_Desktop_Tablet_and_Mobile.py](./TC009_Responsive_UI_Rendering_on_Desktop_Tablet_and_Mobile.py)
- **Test Visualization and Result:** https://www.testsprite.com/dashboard/mcp/tests/97dcf2d5-c58c-4828-b84b-e0379bda862d/bdccca82-c79f-4506-a2e6-91bdd8cb1185
- **Status:** ✅ Passed
- **Analysis / Findings:** {{TODO:AI_ANALYSIS}}.
---

#### Test TC010
- **Test Name:** API Integration Handling Success, Error, and Loading States
- **Test Code:** [TC010_API_Integration_Handling_Success_Error_and_Loading_States.py](./TC010_API_Integration_Handling_Success_Error_and_Loading_States.py)
- **Test Error:** Testing of key API calls for loading indicators, error handling, and data update is incomplete due to backend Internal Server Error on login API call. Loading indicators are shown correctly, but error handling needs improvement with user-friendly messages and retry options. Dashboard data display after successful login could not be verified. Recommend backend fix and UI improvements for error handling.
Browser Console Logs:
[WARNING] %c%s%c [serverFetch] No access token found in cookies background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:2287:27)
[ERROR] %c%s%c [Fetch Error] Status: 404 | URL: http://127.0.0.1:8000/api/vmeg/auth/users/me/ background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] %c%s%c [Fetch Error] Body: background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   <!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <title>Page not found at /api/vmeg/auth/users/me/</title>
  <meta name="robots" content="NONE,NOARCHIVE">
  <style>
    html * { padding:0; margin:0; }
    body * { padding:10px 20px; }
    body * * { padding:0; }
    body { font-family: sans-serif; background:#eee; color:#000; }
    body > :where(header, main, footer) { border-bottom:1px solid #ddd; }
    h1 { font-weight:normal; margin-bottom:.4em; }
    h1 small { font-size:60%; color:#666; font-weight:normal; }
    table { border:none; border-collapse: collapse; width:100%; }
    td, th { vertical-align:top; padding:2px 3px; }
    th { width:12em; text-align:right; color:#666; padding-right:.5em; }
    #info { background:#f6f6f6; }
    #info ol { margin: 0.5em 4em; }
    #info ol li { font-family: monospace; }
    #summary { background: #ffc; }
    #explanation { background:#eee; border-bottom: 0px none; }
    pre.exception_value { font-family: sans-serif; color: #575757; font-size: 1.5em; margin: 10px 0 10px 0; }
  </style>
</head>
<body>
  <header id="summary">
    <h1>Page not found <small>(404)</small></h1>
    
    <table class="meta">
      <tr>
        <th scope="row">Request Method:</th>
        <td>GET</td>
      </tr>
      <tr>
        <th scope="row">Request URL:</th>
        <td>http://127.0.0.1:8000/api/vmeg/auth/users/me/</td>
      </tr>
      
    </table>
  </header>

  <main id="info">
    
      <p>
      Using the URLconf defined in <code>edutrack.urls_public_dynamically_tenant_prefixed</code>,
      Django tried these URL patterns, in this order:
      </p>
      <ol>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                admin/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                public/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                silk/
                
              </code>
            
          </li>
        
      </ol>
      <p>
        
          The current path, <code>api/vmeg/auth/users/me/</code>,
        
        didn’t match any of these.
      </p>
    
  </main>

  <footer id="explanation">
    <p>
      You’re seeing this error because you have <code>DEBUG = True</code> in
      your Django settings file. Change that to <code>False</code>, and Django
      will display a standard 404 page.
    </p>
  </footer>
</body>
</html>
 (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] Failed to load resource: the server responded with a status of 500 (Internal Server Error) (at http://localhost:3000/api/auth/login:0:0)
[ERROR] Login Flow Error: Error: Internal Server Error
    at login (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:24:15)
    at async handleSubmit (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:554:13) (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
- **Test Visualization and Result:** https://www.testsprite.com/dashboard/mcp/tests/97dcf2d5-c58c-4828-b84b-e0379bda862d/4d8e7dc5-ea09-4746-9b16-4407d2c2af45
- **Status:** ❌ Failed
- **Analysis / Findings:** {{TODO:AI_ANALYSIS}}.
---

#### Test TC011
- **Test Name:** Mobile App Permissions and Offline Data Caching
- **Test Code:** [TC011_Mobile_App_Permissions_and_Offline_Data_Caching.py](./TC011_Mobile_App_Permissions_and_Offline_Data_Caching.py)
- **Test Error:** Testing of mobile-specific features including permission requests for storage and camera, handling of permission denial, and offline cached data access could not be fully completed due to an internal server error encountered on the login page after submitting credentials. The issue has been reported for resolution. Further testing should resume once the error is fixed.
Browser Console Logs:
[WARNING] %c%s%c [serverFetch] No access token found in cookies background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:2287:27)
[ERROR] %c%s%c [Fetch Error] Status: 404 | URL: http://127.0.0.1:8000/api/vmeg/auth/users/me/ background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] %c%s%c [Fetch Error] Body: background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   <!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <title>Page not found at /api/vmeg/auth/users/me/</title>
  <meta name="robots" content="NONE,NOARCHIVE">
  <style>
    html * { padding:0; margin:0; }
    body * { padding:10px 20px; }
    body * * { padding:0; }
    body { font-family: sans-serif; background:#eee; color:#000; }
    body > :where(header, main, footer) { border-bottom:1px solid #ddd; }
    h1 { font-weight:normal; margin-bottom:.4em; }
    h1 small { font-size:60%; color:#666; font-weight:normal; }
    table { border:none; border-collapse: collapse; width:100%; }
    td, th { vertical-align:top; padding:2px 3px; }
    th { width:12em; text-align:right; color:#666; padding-right:.5em; }
    #info { background:#f6f6f6; }
    #info ol { margin: 0.5em 4em; }
    #info ol li { font-family: monospace; }
    #summary { background: #ffc; }
    #explanation { background:#eee; border-bottom: 0px none; }
    pre.exception_value { font-family: sans-serif; color: #575757; font-size: 1.5em; margin: 10px 0 10px 0; }
  </style>
</head>
<body>
  <header id="summary">
    <h1>Page not found <small>(404)</small></h1>
    
    <table class="meta">
      <tr>
        <th scope="row">Request Method:</th>
        <td>GET</td>
      </tr>
      <tr>
        <th scope="row">Request URL:</th>
        <td>http://127.0.0.1:8000/api/vmeg/auth/users/me/</td>
      </tr>
      
    </table>
  </header>

  <main id="info">
    
      <p>
      Using the URLconf defined in <code>edutrack.urls_public_dynamically_tenant_prefixed</code>,
      Django tried these URL patterns, in this order:
      </p>
      <ol>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                admin/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                public/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                silk/
                
              </code>
            
          </li>
        
      </ol>
      <p>
        
          The current path, <code>api/vmeg/auth/users/me/</code>,
        
        didn’t match any of these.
      </p>
    
  </main>

  <footer id="explanation">
    <p>
      You’re seeing this error because you have <code>DEBUG = True</code> in
      your Django settings file. Change that to <code>False</code>, and Django
      will display a standard 404 page.
    </p>
  </footer>
</body>
</html>
 (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] Failed to load resource: the server responded with a status of 500 (Internal Server Error) (at http://localhost:3000/api/auth/login:0:0)
[ERROR] Login Flow Error: Error: Internal Server Error
    at login (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:24:15)
    at async handleSubmit (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:554:13) (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
- **Test Visualization and Result:** https://www.testsprite.com/dashboard/mcp/tests/97dcf2d5-c58c-4828-b84b-e0379bda862d/01fbbba3-9fed-49e1-bc29-ef1e952a2907
- **Status:** ❌ Failed
- **Analysis / Findings:** {{TODO:AI_ANALYSIS}}.
---

#### Test TC012
- **Test Name:** Push Notifications and Deep Linking on Mobile
- **Test Code:** [TC012_Push_Notifications_and_Deep_Linking_on_Mobile.py](./TC012_Push_Notifications_and_Deep_Linking_on_Mobile.py)
- **Test Error:** Login failed due to Internal Server Error on the login page. Cannot proceed with push notification and deep link testing. Please resolve the server error to continue testing.
Browser Console Logs:
[ERROR] Failed to load resource: net::ERR_EMPTY_RESPONSE (at http://localhost:3000/_next/static/media/83afe278b6a6bb3c-s.p.3a6ba036.woff2:0:0)
[ERROR] Failed to load resource: net::ERR_EMPTY_RESPONSE (at http://localhost:3000/_next/static/chunks/%5Bturbopack%5D_browser_dev_hmr-client_hmr-client_ts_bae88007._.js:0:0)
[WARNING] %c%s%c [serverFetch] No access token found in cookies background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:2287:27)
[ERROR] %c%s%c [Fetch Error] Status: 404 | URL: http://127.0.0.1:8000/api/vmeg/auth/users/me/ background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] %c%s%c [Fetch Error] Body: background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   <!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <title>Page not found at /api/vmeg/auth/users/me/</title>
  <meta name="robots" content="NONE,NOARCHIVE">
  <style>
    html * { padding:0; margin:0; }
    body * { padding:10px 20px; }
    body * * { padding:0; }
    body { font-family: sans-serif; background:#eee; color:#000; }
    body > :where(header, main, footer) { border-bottom:1px solid #ddd; }
    h1 { font-weight:normal; margin-bottom:.4em; }
    h1 small { font-size:60%; color:#666; font-weight:normal; }
    table { border:none; border-collapse: collapse; width:100%; }
    td, th { vertical-align:top; padding:2px 3px; }
    th { width:12em; text-align:right; color:#666; padding-right:.5em; }
    #info { background:#f6f6f6; }
    #info ol { margin: 0.5em 4em; }
    #info ol li { font-family: monospace; }
    #summary { background: #ffc; }
    #explanation { background:#eee; border-bottom: 0px none; }
    pre.exception_value { font-family: sans-serif; color: #575757; font-size: 1.5em; margin: 10px 0 10px 0; }
  </style>
</head>
<body>
  <header id="summary">
    <h1>Page not found <small>(404)</small></h1>
    
    <table class="meta">
      <tr>
        <th scope="row">Request Method:</th>
        <td>GET</td>
      </tr>
      <tr>
        <th scope="row">Request URL:</th>
        <td>http://127.0.0.1:8000/api/vmeg/auth/users/me/</td>
      </tr>
      
    </table>
  </header>

  <main id="info">
    
      <p>
      Using the URLconf defined in <code>edutrack.urls_public_dynamically_tenant_prefixed</code>,
      Django tried these URL patterns, in this order:
      </p>
      <ol>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                admin/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                public/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                silk/
                
              </code>
            
          </li>
        
      </ol>
      <p>
        
          The current path, <code>api/vmeg/auth/users/me/</code>,
        
        didn’t match any of these.
      </p>
    
  </main>

  <footer id="explanation">
    <p>
      You’re seeing this error because you have <code>DEBUG = True</code> in
      your Django settings file. Change that to <code>False</code>, and Django
      will display a standard 404 page.
    </p>
  </footer>
</body>
</html>
 (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] Failed to load resource: the server responded with a status of 500 (Internal Server Error) (at http://localhost:3000/api/auth/login:0:0)
[ERROR] Login Flow Error: Error: Internal Server Error
    at login (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:24:15)
    at async handleSubmit (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:554:13) (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
- **Test Visualization and Result:** https://www.testsprite.com/dashboard/mcp/tests/97dcf2d5-c58c-4828-b84b-e0379bda862d/12d55b8b-65d4-4daa-9f83-f884729db8e4
- **Status:** ❌ Failed
- **Analysis / Findings:** {{TODO:AI_ANALYSIS}}.
---

#### Test TC013
- **Test Name:** Dashboard Reflects Real-Time AI Verification Status Updates
- **Test Code:** [TC013_Dashboard_Reflects_Real_Time_AI_Verification_Status_Updates.py](./TC013_Dashboard_Reflects_Real_Time_AI_Verification_Status_Updates.py)
- **Test Error:** Login attempts with provided credentials result in persistent Internal Server Error on the login page, preventing access to the student dashboard. Unable to proceed with uploading certificate or verifying AI verification status updates dynamically. Task cannot be completed due to backend issue.
Browser Console Logs:
[WARNING] %c%s%c [serverFetch] No access token found in cookies background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:2287:27)
[ERROR] %c%s%c [Fetch Error] Status: 404 | URL: http://127.0.0.1:8000/api/vmeg/auth/users/me/ background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] %c%s%c [Fetch Error] Body: background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   <!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <title>Page not found at /api/vmeg/auth/users/me/</title>
  <meta name="robots" content="NONE,NOARCHIVE">
  <style>
    html * { padding:0; margin:0; }
    body * { padding:10px 20px; }
    body * * { padding:0; }
    body { font-family: sans-serif; background:#eee; color:#000; }
    body > :where(header, main, footer) { border-bottom:1px solid #ddd; }
    h1 { font-weight:normal; margin-bottom:.4em; }
    h1 small { font-size:60%; color:#666; font-weight:normal; }
    table { border:none; border-collapse: collapse; width:100%; }
    td, th { vertical-align:top; padding:2px 3px; }
    th { width:12em; text-align:right; color:#666; padding-right:.5em; }
    #info { background:#f6f6f6; }
    #info ol { margin: 0.5em 4em; }
    #info ol li { font-family: monospace; }
    #summary { background: #ffc; }
    #explanation { background:#eee; border-bottom: 0px none; }
    pre.exception_value { font-family: sans-serif; color: #575757; font-size: 1.5em; margin: 10px 0 10px 0; }
  </style>
</head>
<body>
  <header id="summary">
    <h1>Page not found <small>(404)</small></h1>
    
    <table class="meta">
      <tr>
        <th scope="row">Request Method:</th>
        <td>GET</td>
      </tr>
      <tr>
        <th scope="row">Request URL:</th>
        <td>http://127.0.0.1:8000/api/vmeg/auth/users/me/</td>
      </tr>
      
    </table>
  </header>

  <main id="info">
    
      <p>
      Using the URLconf defined in <code>edutrack.urls_public_dynamically_tenant_prefixed</code>,
      Django tried these URL patterns, in this order:
      </p>
      <ol>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                admin/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                public/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                silk/
                
              </code>
            
          </li>
        
      </ol>
      <p>
        
          The current path, <code>api/vmeg/auth/users/me/</code>,
        
        didn’t match any of these.
      </p>
    
  </main>

  <footer id="explanation">
    <p>
      You’re seeing this error because you have <code>DEBUG = True</code> in
      your Django settings file. Change that to <code>False</code>, and Django
      will display a standard 404 page.
    </p>
  </footer>
</body>
</html>
 (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] Failed to load resource: the server responded with a status of 500 (Internal Server Error) (at http://localhost:3000/api/auth/login:0:0)
[ERROR] Login Flow Error: Error: Internal Server Error
    at login (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:24:15)
    at async handleSubmit (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:554:13) (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
- **Test Visualization and Result:** https://www.testsprite.com/dashboard/mcp/tests/97dcf2d5-c58c-4828-b84b-e0379bda862d/019b0199-c3cb-415b-ae93-584e9336c772
- **Status:** ❌ Failed
- **Analysis / Findings:** {{TODO:AI_ANALYSIS}}.
---

#### Test TC014
- **Test Name:** Bulk Approval/Rejection Input Edge Cases
- **Test Code:** [TC014_Bulk_ApprovalRejection_Input_Edge_Cases.py](./TC014_Bulk_ApprovalRejection_Input_Edge_Cases.py)
- **Test Error:** Login attempts as faculty failed due to persistent Internal Server Error on the login page. This blocks access to the faculty dashboard and certificate approvals page, preventing further testing of bulk approval/rejection edge cases. Please investigate and resolve the server error to enable testing.
Browser Console Logs:
[WARNING] %c%s%c [serverFetch] No access token found in cookies background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:2287:27)
[ERROR] %c%s%c [Fetch Error] Status: 404 | URL: http://127.0.0.1:8000/api/vmeg/auth/users/me/ background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] %c%s%c [Fetch Error] Body: background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px  Server   <!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <title>Page not found at /api/vmeg/auth/users/me/</title>
  <meta name="robots" content="NONE,NOARCHIVE">
  <style>
    html * { padding:0; margin:0; }
    body * { padding:10px 20px; }
    body * * { padding:0; }
    body { font-family: sans-serif; background:#eee; color:#000; }
    body > :where(header, main, footer) { border-bottom:1px solid #ddd; }
    h1 { font-weight:normal; margin-bottom:.4em; }
    h1 small { font-size:60%; color:#666; font-weight:normal; }
    table { border:none; border-collapse: collapse; width:100%; }
    td, th { vertical-align:top; padding:2px 3px; }
    th { width:12em; text-align:right; color:#666; padding-right:.5em; }
    #info { background:#f6f6f6; }
    #info ol { margin: 0.5em 4em; }
    #info ol li { font-family: monospace; }
    #summary { background: #ffc; }
    #explanation { background:#eee; border-bottom: 0px none; }
    pre.exception_value { font-family: sans-serif; color: #575757; font-size: 1.5em; margin: 10px 0 10px 0; }
  </style>
</head>
<body>
  <header id="summary">
    <h1>Page not found <small>(404)</small></h1>
    
    <table class="meta">
      <tr>
        <th scope="row">Request Method:</th>
        <td>GET</td>
      </tr>
      <tr>
        <th scope="row">Request URL:</th>
        <td>http://127.0.0.1:8000/api/vmeg/auth/users/me/</td>
      </tr>
      
    </table>
  </header>

  <main id="info">
    
      <p>
      Using the URLconf defined in <code>edutrack.urls_public_dynamically_tenant_prefixed</code>,
      Django tried these URL patterns, in this order:
      </p>
      <ol>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                admin/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                public/
                
              </code>
            
          </li>
        
          <li>
            
              <code>
                api/vmeg/
                
              </code>
            
              <code>
                silk/
                
              </code>
            
          </li>
        
      </ol>
      <p>
        
          The current path, <code>api/vmeg/auth/users/me/</code>,
        
        didn’t match any of these.
      </p>
    
  </main>

  <footer id="explanation">
    <p>
      You’re seeing this error because you have <code>DEBUG = True</code> in
      your Django settings file. Change that to <code>False</code>, and Django
      will display a standard 404 page.
    </p>
  </footer>
</body>
</html>
 (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] Failed to load resource: the server responded with a status of 500 (Internal Server Error) (at http://localhost:3000/api/auth/login:0:0)
[ERROR] Login Flow Error: Error: Internal Server Error
    at login (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:24:15)
    at async handleSubmit (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:554:13) (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
[ERROR] Failed to load resource: the server responded with a status of 500 (Internal Server Error) (at http://localhost:3000/api/auth/login:0:0)
[ERROR] Login Flow Error: Error: Internal Server Error
    at login (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:24:15)
    at async handleSubmit (http://localhost:3000/_next/static/chunks/_1c0e909c._.js:554:13) (at http://localhost:3000/_next/static/chunks/node_modules_next_dist_7a8122d0._.js:3117:31)
- **Test Visualization and Result:** https://www.testsprite.com/dashboard/mcp/tests/97dcf2d5-c58c-4828-b84b-e0379bda862d/78b539a4-73c3-4050-b296-fbdf2ef4719f
- **Status:** ❌ Failed
- **Analysis / Findings:** {{TODO:AI_ANALYSIS}}.
---

#### Test TC015
- **Test Name:** UI Accessibility Compliance Checks
- **Test Code:** [TC015_UI_Accessibility_Compliance_Checks.py](./TC015_UI_Accessibility_Compliance_Checks.py)
- **Test Error:** Accessibility testing cannot proceed because the Login page is inaccessible due to a 404 error. The navigation link to the login page is broken. Please fix this issue to enable further testing.
Browser Console Logs:
[ERROR] Failed to load resource: the server responded with a status of 404 (Not Found) (at http://localhost:3000/auth?_rsc=vusbg:0:0)
[ERROR] Failed to load resource: the server responded with a status of 404 (Not Found) (at http://localhost:3000/auth:0:0)
- **Test Visualization and Result:** https://www.testsprite.com/dashboard/mcp/tests/97dcf2d5-c58c-4828-b84b-e0379bda862d/83ebd28d-df95-4f68-851a-fd5e7ffa3c74
- **Status:** ❌ Failed
- **Analysis / Findings:** {{TODO:AI_ANALYSIS}}.
---


## 3️⃣ Coverage & Matching Metrics

- **6.67** of tests passed

| Requirement        | Total Tests | ✅ Passed | ❌ Failed  |
|--------------------|-------------|-----------|------------|
| ...                | ...         | ...       | ...        |
---


## 4️⃣ Key Gaps / Risks
{AI_GNERATED_KET_GAPS_AND_RISKS}
---