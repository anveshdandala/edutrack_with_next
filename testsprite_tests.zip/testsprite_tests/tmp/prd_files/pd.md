\# 🛒 Product Requirement Document (PRD): EduTrack Frontend Testing



| \*\*Project Name\*\* | EduTrack SaaS Platform |

| :--- | :--- |

| \*\*Module\*\* | Frontend (React Web \& Flutter Mobile) |

| \*\*Version\*\* | 1.0 (MVP) |

| \*\*Status\*\* | Draft |

| \*\*Owner\*\* | QA / Frontend Lead |

| \*\*Last Updated\*\* | January 3, 2026 |



---



\## 1. 🎯 Objective

To ensure the stability, responsiveness, and functional correctness of the EduTrack frontend interfaces (Web Portal \& Mobile App) across different tenant schemas. The goal is to catch UI bugs, authentication failures, and API integration errors before production deployment.



---



\## 2. 🧪 Testing Scope



\### 2.1 In-Scope

\* \*\*Authentication Flow:\*\* Login, Logout, Forgot Password, and Tenant Identification.

\* \*\*Role-Based Access Control (RBAC):\*\* UI behavior for Admin vs. Faculty vs. Student.

\* \*\*Multi-Tenancy:\*\* Verifying branding and data isolation for different colleges (e.g., `nit.edutrack.com` vs. `iit.edutrack.com`).

\* \*\*Core Features:\*\* Certificate Upload, Resume Builder, Dashboard Analytics, Chatbot Interface.

\* \*\*API Integration:\*\* Handling success, error, and loading states from the Django Backend.

\* \*\*Responsiveness:\*\* Mobile, Tablet, and Desktop layouts.



\### 2.2 Out-of-Scope

\* Backend Database Schema Migrations (Backend Team).

\* Celery Worker processing speed (Backend Team).

\* Load Testing (handled separately).



---



\## 3. 🛠️ User Stories \& Test Scenarios



\### 3.1 Authentication \& Multi-Tenancy

> \*\*User Story:\*\* As a student from NIT, when I log in, I should see NIT's logo and only my data.



| ID | Scenario | Pre-Conditions | Expected Result | Priority |

| :--- | :--- | :--- | :--- | :--- |

| \*\*AUTH-01\*\* | Login with valid credentials | User exists in DB | Redirect to Dashboard; JWT stored in LocalStorage/SecureStore. | P0 |

| \*\*AUTH-02\*\* | Login with invalid credentials | N/A | Show "Invalid Email or Password" error toast. | P0 |

| \*\*AUTH-03\*\* | Multi-Tenant Routing | Visit `nit.edutrack.com` | Login page displays "NIT" branding/logo. | P1 |

| \*\*AUTH-04\*\* | Cross-Tenant Login Attempt | User is from College A, tries logging into `collegeB.edutrack.com` | Login denied or redirected to correct domain. | P1 |

| \*\*AUTH-05\*\* | Token Expiry | Token expired | User redirected to Login page automatically. | P1 |



\### 3.2 Student Dashboard \& Uploads

> \*\*User Story:\*\* As a student, I want to upload a certificate so it can be verified by AI.



| ID | Scenario | Pre-Conditions | Expected Result | Priority |

| :--- | :--- | :--- | :--- | :--- |

| \*\*STU-01\*\* | Upload Valid Certificate (PDF/IMG) | File < 5MB | "Upload Successful" toast; Status changes to "Processing". | P0 |

| \*\*STU-02\*\* | Upload Invalid File Type (.exe) | N/A | Frontend validation blocks upload; Error message displayed. | P1 |

| \*\*STU-03\*\* | Upload Large File (>10MB) | N/A | Frontend validation blocks upload; "File too large" error. | P1 |

| \*\*STU-04\*\* | AI Verification Status | Upload complete | Dashboard auto-refreshes or polls to show "Verified" status. | P1 |

| \*\*STU-05\*\* | Download Resume | Profile > 80% complete | PDF downloads with correct formatting. | P1 |



\### 3.3 Faculty Dashboard (Approvals)

> \*\*User Story:\*\* As a faculty member, I want to approve pending certificates quickly.



| ID | Scenario | Pre-Conditions | Expected Result | Priority |

| :--- | :--- | :--- | :--- | :--- |

| \*\*FAC-01\*\* | View Pending List | Certificates in "Pending" state | List loads with Student Name, Skill, and Confidence Score. | P0 |

| \*\*FAC-02\*\* | Approve Certificate | "Pending" item selected | Item moves to "Approved" tab; "Approved" toast appears. | P0 |

| \*\*FAC-03\*\* | Reject Certificate | "Pending" item selected | Modal asks for "Rejection Reason"; Item moves to "Rejected". | P1 |

| \*\*FAC-04\*\* | Bulk Approval | Multiple items selected | All selected items update status in one API call. | P2 |



---



\## 4. 🎨 UI/UX Requirements



\### 4.1 Responsiveness Checklist

\* \[ ] \*\*Desktop (1920x1080):\*\* Sidebar expanded, Tables show all columns.

\* \[ ] \*\*Laptop (1366x768):\*\* Layout adjusts, no horizontal scroll on main body.

\* \[ ] \*\*Mobile (375x667):\*\* Sidebar becomes hamburger menu; Tables convert to Cards or scroll horizontally.



\### 4.2 Error Handling Standards

\* \*\*400 Bad Request:\*\* Show specific validation error (e.g., "Email format invalid").

\* \*\*401 Unauthorized:\*\* Redirect to Login immediately.

\* \*\*403 Forbidden:\*\* Show "Access Denied" page (e.g., Student trying to access Admin URL).

\* \*\*500 Server Error:\*\* Show generic "Something went wrong, try again later" friendly message.

\* \*\*Network Error:\*\* Show "No Internet Connection" toast.



---



\## 5. 🤖 Automated Testing Strategy



To ensure speed and reliability, we will use the following tools:



\### 5.1 Unit Testing (Components)

\* \*\*Tool:\*\* Jest + React Testing Library (Web), Flutter Test (Mobile).

\* \*\*Focus:\*\* Individual buttons, input fields, and utility functions.

\* \*\*Success Metric:\*\* >80% Code Coverage.



\### 5.2 Integration Testing (Flows)

\* \*\*Tool:\*\* Cypress (Web), Integration Test package (Flutter).

\* \*\*Focus:\*\*

&nbsp;   \* Login Flow $\\to$ Dashboard Load.

&nbsp;   \* Upload Flow $\\to$ Success Message.

\* \*\*Mocking:\*\* Mock API responses for 200, 400, and 500 status codes.



\### 5.3 End-to-End (E2E) Testing

\* \*\*Tool:\*\* Cypress or Selenium.

\* \*\*Environment:\*\* Staging (Connected to Test DB).

\* \*\*Critical Path:\*\* Full loop: Student Log in $\\to$ Upload Cert $\\to$ Logout $\\to$ Faculty Log in $\\to$ Approve Cert.



---



\## 6. 📱 Mobile Specific Requirements (Flutter)

\* \*\*Permissions:\*\* App must ask for Storage/Camera permissions before upload.

\* \*\*Offline Mode:\*\* App should show cached data if internet is lost.

\* \*\*Push Notifications:\*\* Tapping a notification (e.g., "Certificate Verified") should deep-link to the details page.



---



\## 7. ✅ Acceptance Criteria (Definition of Done)

1\.  All P0 and P1 test cases pass.

2\.  No critical UI bugs (broken layouts, overlapping text) on standard resolutions.

3\.  Authentication token handling is secure (no exposure in URL).

4\.  Cross-tenant access is verifiably blocked.

